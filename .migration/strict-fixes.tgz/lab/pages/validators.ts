import fs from 'node:fs';
import path from 'node:path';
import { URL } from 'node:url';
import { ROOT, SITE, assert, githubSha, isFile, nodeCheck, read, requireFile, stripQuery, walk } from './lib/core.js';

type Attrs = Record<string,string>;
interface HtmlTag { name:string; attrs:Attrs; raw:string; index:number; closing:boolean; }
const VOID_TAGS=new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);
const SOCIAL_HOSTS=new Set(['facebook.com','www.facebook.com','instagram.com','www.instagram.com','tiktok.com','www.tiktok.com','pinterest.com','www.pinterest.com']);

function decodeHtml(value:string):string{return value.replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/&lt;/gi,'<').replace(/&gt;/gi,'>');}
function parseAttrs(raw:string):Attrs{
  const attrs:Attrs={};
  const body=raw.replace(/^<\/?[a-z0-9:-]+/i,'').replace(/\/?\s*>$/,'');
  const re=/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  for(const match of body.matchAll(re)){const key=(match[1]??'').toLowerCase();if(!key)continue;attrs[key]=decodeHtml(match[2]??match[3]??match[4]??'');}
  return attrs;
}
function maskRawText(html:string):string{
  return html.replace(/(<(?<tag>script|style)\b[^>]*>)(?<body>[\s\S]*?)(<\/\k<tag>\s*>)/gi,(_all:string,open:string,_tag:string,_body:string,close:string,...args:unknown[])=>{
    const groups=args.at(-1) as {body?:string}|undefined;
    return open+' '.repeat((groups?.body??'').length)+close;
  });
}
function scanTags(html:string):HtmlTag[]{
  const out:HtmlTag[]=[],masked=maskRawText(html);
  const re=/<\/?[a-zA-Z][^>]*>/g;
  for(const match of masked.matchAll(re)){const raw=match[0],name=/^<\/?\s*([a-z0-9:-]+)/i.exec(raw)?.[1]?.toLowerCase();if(!name||match.index===undefined)continue;out.push({name,attrs:parseAttrs(raw),raw,index:match.index,closing:/^<\//.test(raw)});}
  return out;
}
function classSet(attrs:Attrs):Set<string>{return new Set((attrs.class??'').trim().split(/\s+/).filter(Boolean));}
function urlPath(value:string):string{return stripQuery(value).replace(/^\.\//,'').replace(/^\//,'');}
function remote(value:string):boolean{return /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(value);}
function localResource(value:string):string|null{
  const decoded=decodeHtml(value.trim());
  if(!decoded||/^(?:#|data:|blob:|javascript:|mailto:|tel:)/i.test(decoded)||remote(decoded))return null;
  return decodeURIComponent(stripQuery(decoded));
}
function failList(title:string,issues:string[]):never{const unique=[...new Set(issues)];throw new Error(`${title} with ${unique.length} issue(s):\n${unique.map((item)=>`- ${item}`).join('\n')}`);}

export function validateSnapshotIntegration():void{
  const errors:string[]=[];
  const overrideDir=path.join(ROOT,'override'),bootstrapPath=path.join(ROOT,'_js_dev','main.js'),indexPath=path.join(ROOT,'index.html'),registryPath=path.join(overrideDir,'templates','registry.ts');
  for(const required of [overrideDir,bootstrapPath,indexPath,registryPath])if(!fs.existsSync(required))errors.push(`Missing lab integration input: ${path.relative(ROOT,required)}`);
  if(!errors.length){
    const bootstrap=read(bootstrapPath),index=read(indexPath),registry=read(registryPath);
    if((bootstrap.match(/var version='unversioned';/g)??[]).length!==1)errors.push("Snapshot _js_dev/main.js must contain exactly one var version='unversioned'; placeholder");
    if((index.match(/_js_dev\/main\.js\?v=[^"']+/g)??[]).length!==1)errors.push('Snapshot index.html must reference _js_dev/main.js exactly once');
    if(/data-sc-template=/.test(index))errors.push('Snapshot index.html must not contain override component templates');
    if(!registry.includes('var COMPILED_TEMPLATES=null;/*__SC_TEMPLATE_PAYLOAD__*/'))errors.push('Pages lab requires the optional compiled-template injection slot in override/templates/registry.ts');
  }
  if(errors.length)failList('Pages lab snapshot/override integration validation failed',errors);
  console.log('Pages lab snapshot/override integration validation passed.');
}

export function validateJsSyntax():void{
  const roots=[path.join(SITE,'override'),path.join(SITE,'_pages')];let checked=0;
  for(const root of roots)for(const file of walk(root).filter((item)=>item.endsWith('.js'))){nodeCheck(file);checked++;}
  console.log(`Pages JavaScript syntax validation passed: ${checked} generated/runtime files checked.`);
}

export function validateLocalAssets():void{
  const index=path.join(SITE,'index.html');assert(isFile(index),'Prepared Pages artifact is missing');
  const missing:string[]=[],checked=new Set<string>();
  const check=(value:string,base=SITE):void=>{
    const local=localResource(value);if(local===null)return;
    if(local.startsWith('/')){missing.push(`root-relative resource is invalid for project Pages: ${value}`);return;}
    const target=path.resolve(base,local);
    if(target!==SITE&&!target.startsWith(`${SITE}${path.sep}`)){missing.push(`resource escapes Pages artifact: ${value}`);return;}
    if(checked.has(target))return;checked.add(target);if(!isFile(target))missing.push(`missing local resource: ${value} -> ${path.relative(SITE,target).replaceAll(path.sep,'/')}`);
  };
  for(const tag of scanTags(read(index))){if(tag.closing)continue;const attrs=tag.attrs;
    if(tag.name==='link'){const rel=new Set((attrs.rel??'').toLowerCase().split(/\s+/));if(!['stylesheet','preload','prefetch','icon','shortcut','apple-touch-icon'].some((v)=>rel.has(v)))continue;if(attrs.href)check(attrs.href);continue;}
    const keys:Record<string,string[]>={script:['src'],img:['src','srcset'],source:['src','srcset'],video:['src','poster'],audio:['src'],iframe:['src']};
    for(const key of keys[tag.name]??[]){const value=attrs[key];if(!value)continue;if(key==='srcset'){for(const part of value.split(',')){const candidate=part.trim().split(/\s+/,1)[0];if(candidate)check(candidate);}}else check(value);}
  }
  const cssPaths=[path.join(SITE,'_pages','legacy.css'),path.join(SITE,'override','main.css')];
  for(const css of cssPaths){if(!isFile(css)){missing.push(`missing active stylesheet: ${path.relative(SITE,css)}`);continue;}for(const match of read(css).matchAll(/url\(\s*(["']?)(.*?)\1\s*\)/gi)){const value=match[2];if(value)check(value,path.dirname(css));}}
  if(missing.length)failList('Pages local asset validation failed',missing);
  console.log(`Pages local asset validation passed: ${checked.size} unique local resources resolved.`);
}

export function validateHtml():void{
  const index=path.join(SITE,'index.html');assert(isFile(index),'Prepared Pages artifact is missing');const html=read(index),issues:string[]=[];if(html.includes('\uFFFD'))issues.push('index.html contains Unicode replacement character U+FFFD');
  const tags=scanTags(html),ids:string[]=[],fragments:string[]=[],labels=new Set<string>(),controls:{tag:string;attrs:Attrs}[]=[],imgStyles:string[]=[],social:{href:string;named:boolean}[]=[];
  const stack:{name:string;textStart:number;tag:HtmlTag;imgAlt:string}[]=[];
  for(const tag of tags){if(tag.closing){for(let i=stack.length-1;i>=0;i--){const item=stack[i];if(item?.name!==tag.name)continue;const segment=html.slice(item.textStart,tag.index).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();if(item.name==='a'){const href=(item.tag.attrs.href??'').trim();let host='';try{host=new URL(href).hostname.toLowerCase();}catch{}if(host&&SOCIAL_HOSTS.has(host)){const named=Boolean(segment||(item.tag.attrs['aria-label']??'').trim()||(item.tag.attrs.title??'').trim()||item.imgAlt);social.push({href,named});}}stack.splice(i);break;}continue;}
    if(tag.attrs.id)ids.push(tag.attrs.id);if(tag.name==='label'&&tag.attrs.for)labels.add(tag.attrs.for);
    if(tag.name==='a'){const href=(tag.attrs.href??'').trim();if(href.startsWith('#')&&href.length>1)fragments.push(decodeURIComponent(decodeHtml(href.slice(1))));}
    if(tag.name==='div'&&classSet(tag.attrs).has('imgShop')&&tag.attrs.style!==undefined)imgStyles.push(tag.attrs.style);
    if(['input','select','textarea'].includes(tag.name)){const inputType=(tag.attrs.type??'').toLowerCase();if(!(tag.name==='input'&&['hidden','submit','button','image','reset'].includes(inputType)))controls.push({tag:tag.name,attrs:tag.attrs});}
    if(tag.name==='img'&&tag.attrs.alt){for(const item of stack)item.imgAlt=tag.attrs.alt;}
    if(!VOID_TAGS.has(tag.name)&&!tag.raw.endsWith('/>'))stack.push({name:tag.name,textStart:tag.index+tag.raw.length,tag,imgAlt:''});
  }
  const counts=new Map<string,number>();for(const id of ids)counts.set(id,(counts.get(id)??0)+1);for(const [id,count] of counts)if(count>1)issues.push(`duplicate id '${id}' appears ${count} times`);
  const idSet=new Set(ids);for(const fragment of new Set(fragments))if(!idSet.has(fragment))issues.push(`fragment target does not exist: #${fragment}`);
  for(const style of imgStyles){const normalized=decodeHtml(style).trim();if(normalized.startsWith('uploads_shop/')||normalized.startsWith('url('))issues.push(`malformed imgShop inline style: ${style.slice(0,120)}`);if(/(^|;)\s*background-(?:image|size|position|repeat)\s*:/i.test(normalized))issues.push('imgShop retains eager imgLiquid background styles after cleanup');}
  for(const control of controls){const a=control.attrs;const named=Boolean((a['aria-label']??'').trim()||(a['aria-labelledby']??'').trim()||(a.title??'').trim()||(a.id&&labels.has(a.id)));if(!named)issues.push(`form control lacks an accessible name: ${control.tag}[${a.name||a.id||'<unnamed>'}]`);}
  for(const link of social)if(!link.named)issues.push(`social link lacks an accessible name: ${link.href}`);
  const unpinned:string[]=[];for(const file of walk(path.join(SITE,'override')).filter((item)=>item.endsWith('.js')))if(read(file).includes('cdn.jsdelivr.net/npm/gsap@3/dist/'))unpinned.push(path.relative(SITE,file).replaceAll(path.sep,'/'));if(unpinned.length)issues.push(`unpinned GSAP CDN reference(s): ${unpinned.sort().join(', ')}`);
  if(issues.length)failList('Pages HTML validation failed',issues);
  console.log(`Pages HTML validation passed: ${ids.length} ids, ${fragments.length} fragment links, ${controls.length} form controls, ${social.length} social links checked.`);
}

export function validatePerformanceBudget(stage:'pre'|'final'='pre'):void{
  const index=path.join(SITE,'index.html');assert(isFile(index),'Prepared Pages index is missing');const tags=scanTags(read(index)),scripts:string[]=[],styles:string[]=[],remoteBlocking:string[]=[],preloads:Array<[string,string,Attrs]>=[],productImages:Attrs[]=[],banners:Attrs[]=[];const stack:{name:string;classes:Set<string>}[]=[];
  for(const tag of tags){if(tag.closing){for(let i=stack.length-1;i>=0;i--){if(stack[i]?.name===tag.name){stack.splice(i);break;}}continue;}const parentClasses=new Set<string>();for(const item of stack)for(const value of item.classes)parentClasses.add(value);const a=tag.attrs;
    if(tag.name==='script'&&a.src){if(remote(a.src)){if(a.async===undefined&&a.defer===undefined)remoteBlocking.push(a.src);}else scripts.push(urlPath(a.src));}
    else if(tag.name==='link'&&a.href){const rel=new Set((a.rel??'').toLowerCase().split(/\s+/));if(rel.has('stylesheet')&&!remote(a.href))styles.push(urlPath(a.href));if(rel.has('preload'))preloads.push([(a.as??'').toLowerCase(),urlPath(a.href),a]);}
    else if(tag.name==='img'){const classes=classSet(a);if(parentClasses.has('imgShop'))productImages.push(a);if(classes.has('imgBannerShop'))banners.push(a);}
    if(!VOID_TAGS.has(tag.name)&&!tag.raw.endsWith('/>'))stack.push({name:tag.name,classes:classSet(a)});
  }
  const errors:string[]=[];
  if(stage==='pre'){
    const expectedScripts=new Set(['js/jquery-2.1.0.min.js','_pages/legacy.js','_js_dev/main-legacy.js','override/main.js','_pages/shop.js']),actualScripts=new Set(scripts);if(actualScripts.size!==expectedScripts.size||[...expectedScripts].some((v)=>!actualScripts.has(v)))errors.push(`local script topology changed: expected=${JSON.stringify([...expectedScripts].sort())}, actual=${JSON.stringify([...actualScripts].sort())}`);if(scripts.length!==actualScripts.size)errors.push(`duplicate local script request(s): ${scripts.join(', ')}`);
    const expectedStyles=new Set(['_pages/legacy.css','override/main.css']),actualStyles=new Set(styles);if(actualStyles.size!==expectedStyles.size||[...expectedStyles].some((v)=>!actualStyles.has(v)))errors.push(`local stylesheet topology changed: expected=${JSON.stringify([...expectedStyles].sort())}, actual=${JSON.stringify([...actualStyles].sort())}`);if(styles.length!==actualStyles.size)errors.push(`duplicate local stylesheet request(s): ${styles.join(', ')}`);
    if(remoteBlocking.length)errors.push(`blocking remote scripts detected: ${remoteBlocking.join(', ')}`);if(!productImages.length)errors.push('no product images detected');else{const bad:number[]=[];productImages.forEach((a,i)=>{if(a.loading!=='lazy'||a.decoding!=='async'||(a.fetchpriority??'').toLowerCase()==='high')bad.push(i+1);});if(bad.length)errors.push(`product images outside lazy/async budget: ${[...new Set(bad)].slice(0,20).join(', ')}`);}if(banners.length!==1)errors.push(`expected exactly one catalogue banner, found ${banners.length}`);else{const banner=banners[0]!;if(banner.loading!=='eager'||banner.decoding!=='async'||banner.fetchpriority!=='high')errors.push('catalogue banner lost eager/async/high-priority attributes');const bannerSrc=urlPath(banner.src??''),imagePreloads=preloads.filter(([kind])=>kind==='image').map(([,href])=>href);if(imagePreloads.filter((href)=>href===bannerSrc).length!==1)errors.push(`catalogue banner preload mismatch: banner=${bannerSrc}, image_preloads=${imagePreloads.join(', ')}`);}
    const required=new Set(['script|_js_dev/main-legacy.js','style|override/main.css','script|override/main.js','font|_remote-assets/fuentes/AcuminPro-Regular.woff2','font|_remote-assets/fuentes/AcuminPro-Semibold.woff2']),actual=new Set(preloads.map(([kind,href])=>`${kind}|${href}`));const missing=[...required].filter((v)=>!actual.has(v));if(missing.length)errors.push(`missing critical preload(s): ${missing.join(', ')}`);
  }
  if(errors.length)failList('Pages performance budget failed',errors);console.log(`Pages performance budget passed (${stage}): ${scripts.length} local scripts, ${styles.length} local stylesheets, ${productImages.length} product images, ${preloads.length} preload hints.`);
}

export function validateSystemLoad():void{
  const sha=githubSha(),index=path.join(SITE,'index.html');assert(isFile(index),'invalid system-load validation context');const html=read(index),tags=scanTags(html),scripts:string[]=[],styles:string[]=[],images:string[]=[],preloads:string[]=[];
  for(const tag of tags){if(tag.closing)continue;const a=tag.attrs;if(tag.name==='script'&&a.src)scripts.push(a.src);else if(tag.name==='link'&&a.href){const rel=new Set((a.rel??'').toLowerCase().split(/\s+/));if(rel.has('stylesheet'))styles.push(a.href);if(rel.has('preload'))preloads.push(a.href);}else if(tag.name==='img'&&a.src)images.push(a.src);}
  const issues:string[]=[],logo=`_critical-media/sushiclub-logo.svg?v=${sha}`;if(images.filter((v)=>v===logo).length!==2||preloads.filter((v)=>v===logo).length!==1)issues.push(`system logo load contract mismatch: images=${images.filter((v)=>v===logo).length} preloads=${preloads.filter((v)=>v===logo).length}`);
  for(const stale of ['web-sushiclub2_black_m2','web-sushiclub2_black.png','_critical-media/mobile-logo.png','_critical-media/mobile-logo.webp','_chrome-media/desktop-logo.webp'])if(html.includes(stale))issues.push(`superseded logo reference remains active/generated: ${stale}`);
  for(const stale of ['_critical-media/mobile-logo.png','_critical-media/mobile-logo.webp','_chrome-media/desktop-logo.webp'])if(fs.existsSync(path.join(SITE,stale)))issues.push(`superseded logo file remains in artifact: ${stale}`);
  const traitTags=html.match(/<img\b(?=[^>]*\bdata-original-title=)[^>]*>/gi)??[];if(!traitTags.length)issues.push('legacy trait metadata nodes are missing');if(traitTags.some((tag)=>/\bsrc\s*=/i.test(tag)))issues.push('legacy trait metadata still has an active img src');
  for(const stale of ['https://www.sushiclub.com.ar/gfx/back_body_01.png','https://www.sushiclub.com.ar/gfx/back_body_01_white.png','https://www.sushiclub.com.ar/gfx/scrollTab2.png'])if(html.includes(stale))issues.push(`superseded CSS raster remains in final browser graph: ${stale}`);
  const manifest="A=['js/jquery-2.1.0.min.js','_pages/php-guard.js?v='+S,'_pages/legacy.js?v='+S,'_js_dev/main-legacy.js?v='+S,'override/main.js?v='+S,'_pages/shop.js?v='+S]";if(html.split(manifest).length-1!==1)issues.push(`optimized deferred runtime manifest count must be 1, found ${html.split(manifest).length-1}`);if(!isFile(path.join(SITE,'_pages/php-guard.js')))issues.push('static Pages PHP transport guard is missing');if(html.includes('keepSessionAlive')||html.includes('keepalive: 1'))issues.push('captured PHP session keepalive remains in final Pages HTML');if(html.split("'_pages/php-guard.js?v='+S").length-1!==1)issues.push('PHP transport guard runtime reference is missing or duplicated');if(html.split("c.href='_pages/deferred.css?v='+S").length-1!==1)issues.push('optimized deferred stylesheet loader is missing or duplicated');
  for(const source of ['js/funcionesShop__q_f352afe3.js','js/main_shop__q_a48cd660.js'])if(html.includes(source))issues.push(`superseded shop script is still referenced by browser load graph: ${source}`);
  const activeStyles=styles.map(urlPath);for(const p of activeStyles)if(p.startsWith('_css_dev/')||['_pages/legacy.css','override/main.css','css/styles_shop__q_a48cd660.css','css/_aux__q_a48cd660.css'].includes(p))issues.push(`superseded stylesheet is still loaded directly: ${p}`);for(const p of new Set(activeStyles))if(activeStyles.filter((v)=>v===p).length>1)issues.push(`duplicate eager stylesheet load (${activeStyles.filter((v)=>v===p).length}x): ${p}`);if(html.split('id="sc-pages-critical-css"').length-1!==1)issues.push('critical inline CSS block missing or duplicated');
  const activeScripts=scripts.map(urlPath);for(const p of new Set(activeScripts))if(activeScripts.filter((v)=>v===p).length>1)issues.push(`duplicate eager script load (${activeScripts.filter((v)=>v===p).length}x): ${p}`);
  if(html.includes('aniversario_banner_desktop_(1)1782398717_556.webp'))issues.push('upstream banner remains referenced after responsive localization');if(!html.includes(`_critical-media/desktop-banner.webp?v=${sha}`))issues.push('optimized desktop banner reference missing');if(!html.includes(`_critical-media/mobile-banner.webp?v=${sha}`))issues.push('optimized mobile banner reference missing');
  if(issues.length)failList('System load validation failed',issues);console.log(`System load validation passed: ${scripts.length} eager scripts, ${styles.length} eager stylesheets, ${images.length} src-bearing images and ${preloads.length} preloads audited; ${traitTags.length} legacy trait nodes retained as metadata only.`);
}

export function validateFinalInvariants():void{
  const sha=githubSha(),index=path.join(SITE,'index.html');requireFile(index,'Pages final index is missing');const html=read(index),issues:string[]=[];
  for(const marker of ['id="sc-pages-critical-css"','id="sc-pages-delivery-loader"','id="sc-theme-prepaint"','id="sc-product-lcp-preload"',"'_pages/php-guard.js?v='+S"])if(!html.includes(marker))issues.push(`missing final invariant marker: ${marker}`);
  for(const file of ['_pages/deferred.css','_pages/php-guard.js','_critical-media/sushiclub-logo.svg','_critical-media/mobile-banner.webp'])if(!isFile(path.join(SITE,file))||fs.statSync(path.join(SITE,file)).size===0)issues.push(`missing final invariant file: ${file}`);
  for(const file of ['_critical-media/mobile-logo.webp','_chrome-media/desktop-logo.webp','.system-logo-optics.json'])if(fs.existsSync(path.join(SITE,file)))issues.push(`superseded final file remains: ${file}`);
  if((html.match(/class="[^"]*sc-system-brand-logo[^"]*"/g)??[]).length!==2)issues.push('system brand logo count must be exactly 2');if(html.split('data-sc-first-viewport=').length-1!==4)issues.push('first viewport marker count must be exactly 4');
  for(let n=1;n<=4;n++){const file=path.join(SITE,`_first-viewport/product-${n}.webp`);if(!isFile(file)||fs.statSync(file).size>36_000)issues.push(`first viewport product ${n} missing or over budget`);const re=new RegExp(`<img[^>]*data-sc-first-viewport=["']${n}["'][^>]*src=["']_first-viewport/product-${n}\\.webp\\?v=${sha}["'][^>]*loading=["']eager["'][^>]*fetchpriority=["']high["']`,'i');if(!re.test(html))issues.push(`first viewport product ${n} lost eager/high contract`);}
  for(const marker of ["querySelectorAll('img[data-sc-first-viewport]')","querySelectorAll('img[data-sc-desktop-src]')"])if(!html.includes(marker))issues.push(`missing loader marker: ${marker}`);
  if(/<img[^>]*data-sc-first-viewport=["'][1-4]["'][^>]*loading=["']lazy["']/i.test(html))issues.push('First-viewport LCP candidate is still lazy-loaded');const deferred=isFile(path.join(SITE,'_pages/deferred.css'))?read(path.join(SITE,'_pages/deferred.css')):'';if((deferred+html).includes('fonts.gstatic.com'))issues.push('Remote Google font remains in the Pages critical dependency graph');if((deferred+html).includes('fonts.googleapis.com'))issues.push('Google Fonts stylesheet remains in the Pages artifact');if(deferred.includes('fontawesome-webfont.woff2')&&!html.includes('id="sc-fontawesome-preload"'))issues.push('FontAwesome remains deferred without its preload');
  for(const stale of ['keepSessionAlive','_critical-media/mobile-logo.png?v=','_critical-media/mobile-logo.webp?v=','_chrome-media/desktop-logo.webp?v='])if(html.includes(stale))issues.push(`forbidden final runtime reference remains: ${stale}`);if(/<link[^>]*rel=["']stylesheet["'][^>]*href=["'](?:_pages\/legacy\.css|override\/main\.css)\?v=/i.test(html))issues.push('blocking legacy/override stylesheet remains in lab artifact');
  if(issues.length)failList('Pages final invariant validation failed',issues);console.log('Pages final invariant validation passed.');
}
